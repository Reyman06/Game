﻿namespace Ray1Editor;

/// <summary>
/// Interaction logic for EditorControlsWindow.xaml
/// </summary>
public partial class EditorControlsWindow : BaseWindow
{
    public EditorControlsWindow()
    {
        InitializeComponent();
    }
}