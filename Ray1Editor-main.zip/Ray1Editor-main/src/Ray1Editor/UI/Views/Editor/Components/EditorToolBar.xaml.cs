﻿using System.Windows.Controls;

namespace Ray1Editor;

/// <summary>
/// Interaction logic for EditorToolBar.xaml
/// </summary>
public partial class EditorToolBar : ToolBar
{
    public EditorToolBar()
    {
        InitializeComponent();
    }
}