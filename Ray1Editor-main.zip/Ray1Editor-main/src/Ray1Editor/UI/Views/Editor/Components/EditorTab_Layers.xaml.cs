﻿using System.Windows.Controls;

namespace Ray1Editor;

/// <summary>
/// Interaction logic for EditorTab_Layers.xaml
/// </summary>
public partial class EditorTab_Layers : UserControl
{
    public EditorTab_Layers()
    {
        InitializeComponent();
    }
}