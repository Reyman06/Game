﻿namespace Ray1Editor;

public enum EditorMode
{
    None,
    Layers,
    Objects,
    Links,
}