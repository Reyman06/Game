﻿using Microsoft.Xna.Framework;

namespace Ray1Editor;

public class ObjAnimation_HitBoxLayer
{
    public Rectangle Rectangle { get; set; }
}